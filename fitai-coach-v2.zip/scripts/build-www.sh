#!/usr/bin/env bash
# Builds the Capacitor web bundle (www/) from the source files in the repo root.
# The native app opens straight into the app (www/index.html = app.html), with no
# marketing landing page, no promo video and no Google Ads tag.
set -euo pipefail
cd "$(dirname "$0")/.."

rm -rf www
mkdir -p www

cp app.html www/index.html
cp app.html www/app.html
cp fitai.css fitai.js firebase-config.js workout-database.js logo.png www/
cp privacy-policy.html terms-and-conditions.html delete-account.html www/

# Strip Google Ads / gtag blocks from pages shown inside the native app
# (in-app ad tracking would require App Tracking Transparency on iOS).
for f in www/*.html; do
  perl -0pi -e 's{\s*<!-- Google tag \(gtag\.js\) -->\s*}{\n}g; s{<script async src="https://www\.googletagmanager\.com/gtag/js[^"]*"></script>\s*<script>.*?</script>}{}gs' "$f"
done

echo "www/ rebuilt:"
ls -la www
echo "Next: npx cap sync"
