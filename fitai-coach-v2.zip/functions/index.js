/**
 * FitAI Coach — Cloud Functions (v2)
 *
 * Every client-facing endpoint now verifies the caller's Firebase ID token.
 * The old version trusted a `userId` sent in the request body, which let anyone
 * open another user's billing portal or read their subscription status.
 *
 * Secrets (set once):
 *   firebase functions:secrets:set STRIPE_SECRET_KEY
 *   firebase functions:secrets:set STRIPE_WEBHOOK_SECRET
 *   firebase functions:secrets:set ANTHROPIC_API_KEY
 *   firebase functions:secrets:set REVENUECAT_WEBHOOK_AUTH   (long random string; use the same value in RevenueCat > Webhooks > Authorization header as "Bearer <value>")
 *
 * Plain env (functions/.env):
 *   APP_URL=https://www.mindpilot.online
 *   STRIPE_PRICE_ID=price_xxx
 *   AI_MODEL=claude-haiku-5-5
 */

const { onRequest } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const admin = require("firebase-admin");
const cors = require("cors")({ origin: true });
const Stripe = require("stripe");

admin.initializeApp();
const db = admin.firestore();

const STRIPE_SECRET_KEY = defineSecret("STRIPE_SECRET_KEY");
const STRIPE_WEBHOOK_SECRET = defineSecret("STRIPE_WEBHOOK_SECRET");
const ANTHROPIC_API_KEY = defineSecret("ANTHROPIC_API_KEY");
const REVENUECAT_WEBHOOK_AUTH = defineSecret("REVENUECAT_WEBHOOK_AUTH");

const REGION = "us-central1";
const FREE_AI_PER_DAY = 5;
const PREMIUM_AI_PER_DAY = 100;

let _stripe = null;
function getStripe() {
  if (!_stripe) _stripe = Stripe(STRIPE_SECRET_KEY.value());
  return _stripe;
}

// ---------- helpers ----------
async function requireUser(req) {
  const m = (req.headers.authorization || "").match(/^Bearer (.+)$/);
  if (!m) {
    const err = new Error("Sign in required");
    err.status = 401;
    throw err;
  }
  try {
    return await admin.auth().verifyIdToken(m[1]);
  } catch (e) {
    const err = new Error("Session expired. Sign in again.");
    err.status = 401;
    throw err;
  }
}

function handle(fn) {
  return (req, res) => {
    cors(req, res, async () => {
      if (req.method === "OPTIONS") return res.status(204).send("");
      if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
      try {
        await fn(req, res);
      } catch (e) {
        console.error(e);
        res.status(e.status || 500).json({ error: e.status ? e.message : "Server error" });
      }
    });
  };
}

const todayKey = () => new Date().toISOString().slice(0, 10);

async function setPremium(uid, isPremium, extra) {
  await db.collection("users").doc(uid).set(
    Object.assign(
      { isPremium: !!isPremium, subscriptionUpdatedAt: admin.firestore.FieldValue.serverTimestamp() },
      extra || {}
    ),
    { merge: true }
  );
}

// ---------- Stripe (web only; native apps must use store billing) ----------
exports.createCheckoutSession = onRequest(
  { region: REGION, secrets: [STRIPE_SECRET_KEY] },
  handle(async (req, res) => {
    const user = await requireUser(req);
    const stripe = getStripe();
    const appUrl = process.env.APP_URL || "https://www.mindpilot.online";
    const ref = db.collection("users").doc(user.uid);
    const snap = await ref.get();
    let customerId = snap.exists ? snap.data().stripeCustomerId : null;
    if (!customerId) {
      const c = await stripe.customers.create({ email: user.email || undefined, metadata: { firebaseUID: user.uid } });
      customerId = c.id;
      await ref.set({ stripeCustomerId: customerId }, { merge: true });
    }
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: "subscription",
      line_items: [{ price: process.env.STRIPE_PRICE_ID, quantity: 1 }],
      success_url: `${appUrl}/app.html?payment=success`,
      cancel_url: `${appUrl}/app.html?payment=cancelled`,
      metadata: { firebaseUID: user.uid },
      subscription_data: { metadata: { firebaseUID: user.uid } },
    });
    res.status(200).json({ url: session.url });
  })
);

exports.createPortalSession = onRequest(
  { region: REGION, secrets: [STRIPE_SECRET_KEY] },
  handle(async (req, res) => {
    const user = await requireUser(req);
    const snap = await db.collection("users").doc(user.uid).get();
    if (!snap.exists || !snap.data().stripeCustomerId) {
      return res.status(404).json({ error: "No web subscription found for this account" });
    }
    const appUrl = process.env.APP_URL || "https://www.mindpilot.online";
    const s = await getStripe().billingPortal.sessions.create({
      customer: snap.data().stripeCustomerId,
      return_url: `${appUrl}/app.html`,
    });
    res.status(200).json({ url: s.url });
  })
);

exports.checkSubscriptionStatus = onRequest(
  { region: REGION },
  handle(async (req, res) => {
    const user = await requireUser(req);
    const snap = await db.collection("users").doc(user.uid).get();
    const d = snap.exists ? snap.data() : {};
    res.status(200).json({
      isPremium: !!d.isPremium,
      subscriptionStatus: d.subscriptionStatus || "none",
      premiumSource: d.premiumSource || null,
    });
  })
);

exports.stripeWebhook = onRequest(
  { region: REGION, secrets: [STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET] },
  async (req, res) => {
    let event;
    try {
      event = getStripe().webhooks.constructEvent(req.rawBody, req.headers["stripe-signature"], STRIPE_WEBHOOK_SECRET.value());
    } catch (err) {
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }
    try {
      const o = event.data.object;
      const uid = o.metadata && o.metadata.firebaseUID;
      if (event.type === "checkout.session.completed" && uid) {
        await setPremium(uid, true, {
          premiumSource: "stripe",
          stripeSubscriptionId: o.subscription,
          stripeCustomerId: o.customer,
          subscriptionStatus: "active",
        });
      } else if (event.type === "customer.subscription.updated" && uid) {
        await setPremium(uid, ["active", "trialing"].includes(o.status), { premiumSource: "stripe", subscriptionStatus: o.status });
      } else if (event.type === "customer.subscription.deleted" && uid) {
        await setPremium(uid, false, { premiumSource: "stripe", subscriptionStatus: "cancelled" });
      } else if (event.type === "invoice.payment_failed") {
        const q = await db.collection("users").where("stripeCustomerId", "==", o.customer).limit(1).get();
        if (!q.empty) await q.docs[0].ref.set({ subscriptionStatus: "past_due" }, { merge: true });
      }
    } catch (e) {
      console.error("Stripe webhook processing error:", e);
      return res.status(500).send("Webhook processing error");
    }
    res.status(200).json({ received: true });
  }
);

// ---------- RevenueCat webhook: source of truth for Google Play / App Store ----------
// RevenueCat > Integrations > Webhooks. The app logs in with the Firebase UID,
// so app_user_id == Firebase UID.
exports.revenuecatWebhook = onRequest(
  { region: REGION, secrets: [REVENUECAT_WEBHOOK_AUTH] },
  async (req, res) => {
    if (req.headers.authorization !== `Bearer ${REVENUECAT_WEBHOOK_AUTH.value()}`) {
      return res.status(401).send("Unauthorized");
    }
    const e = (req.body && req.body.event) || {};
    const uid = e.app_user_id;
    if (!uid || String(uid).startsWith("$RCAnonymousID")) return res.status(200).send("ignored");
    const src = { premiumSource: e.store || "store" };
    try {
      if (["INITIAL_PURCHASE", "RENEWAL", "UNCANCELLATION", "PRODUCT_CHANGE", "NON_RENEWING_PURCHASE"].includes(e.type)) {
        await setPremium(uid, true, Object.assign({ subscriptionStatus: "active" }, src));
      } else if (e.type === "EXPIRATION") {
        await setPremium(uid, false, Object.assign({ subscriptionStatus: "expired" }, src));
      } else if (e.type === "CANCELLATION") {
        await db.collection("users").doc(uid).set({ subscriptionStatus: "cancelled_pending_expiry" }, { merge: true });
      } else if (e.type === "BILLING_ISSUE") {
        await db.collection("users").doc(uid).set({ subscriptionStatus: "billing_issue" }, { merge: true });
      }
    } catch (err) {
      console.error("RevenueCat webhook error:", err);
      return res.status(500).send("error");
    }
    res.status(200).send("ok");
  }
);

// ---------- AI Coach: real model replies, quota enforced on the server ----------
const COACH_SYSTEM = `You are FitAI Coach, a supportive fitness and nutrition coach for users in Malaysia and Southeast Asia.
- Reply in the user's language (English or Bahasa Melayu). Keep replies under 180 words, practical and specific.
- Use the user profile to personalise advice. Prefer local, halal-friendly food examples when the diet allows.
- You are not a doctor. For pain, injury, pregnancy, eating disorders, chest pain, dizziness, medication or medical conditions, tell the user to see a qualified healthcare professional and do not prescribe.
- Never recommend intake below 1,200 kcal/day for women or 1,500 kcal/day for men, drugs, or unsafe supplements.
- If someone mentions self-harm, respond with care and point them to Befrienders KL (03-7627 2929) or emergency services (999).`;

exports.aiCoach = onRequest(
  { region: REGION, secrets: [ANTHROPIC_API_KEY], timeoutSeconds: 60 },
  handle(async (req, res) => {
    const user = await requireUser(req);
    const { messages, profile, lang } = req.body || {};
    if (!Array.isArray(messages) || !messages.length) return res.status(400).json({ error: "No message" });

    const us = await db.collection("users").doc(user.uid).get();
    const isPremium = us.exists && !!us.data().isPremium;
    const limit = isPremium ? PREMIUM_AI_PER_DAY : FREE_AI_PER_DAY;
    const usageRef = db.collection("users").doc(user.uid).collection("usage").doc(todayKey());

    const used = await db.runTransaction(async (t) => {
      const s = await t.get(usageRef);
      const n = s.exists ? s.data().aiMessages || 0 : 0;
      if (n >= limit) return -1;
      t.set(usageRef, { aiMessages: n + 1 }, { merge: true });
      return n + 1;
    });
    if (used < 0) return res.status(429).json({ error: "daily_limit", limit, isPremium });

    const clean = messages
      .slice(-12)
      .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }));
    while (clean.length && clean[0].role !== "user") clean.shift();
    if (!clean.length) return res.status(400).json({ error: "No message" });

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": ANTHROPIC_API_KEY.value(),
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: process.env.AI_MODEL || "claude-haiku-5-5",
        max_tokens: 500,
        system: `${COACH_SYSTEM}\nPreferred language: ${lang === "bm" ? "Bahasa Melayu" : "English"}.\nUser profile: ${JSON.stringify(profile || {}).slice(0, 800)}`,
        messages: clean,
      }),
    });
    if (!r.ok) {
      console.error("AI error", r.status, await r.text());
      await usageRef.set({ aiMessages: admin.firestore.FieldValue.increment(-1) }, { merge: true });
      return res.status(502).json({ error: "ai_unavailable" });
    }
    const data = await r.json();
    const reply = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n").trim();
    res.status(200).json({ reply, remaining: limit - used, isPremium });
  })
);

// ---------- Account deletion (required by Google Play and the App Store) ----------
exports.deleteAccount = onRequest(
  { region: REGION, secrets: [STRIPE_SECRET_KEY] },
  handle(async (req, res) => {
    const { uid } = await requireUser(req);
    const ref = db.collection("users").doc(uid);
    const snap = await ref.get();

    if (snap.exists && snap.data().stripeSubscriptionId) {
      try {
        await getStripe().subscriptions.cancel(snap.data().stripeSubscriptionId);
      } catch (e) {
        console.warn("Stripe cancel:", e.message);
      }
    }

    await db.recursiveDelete(ref);
    for (const col of ["progressData", "chatHistory"]) {
      await db.recursiveDelete(db.collection(col).doc(uid)).catch(() => {});
    }
    for (const [col, field] of [["workoutPlans", "userId"], ["progressPhotos", "userId"], ["aiReports", "uid"]]) {
      const q = await db.collection(col).where(field, "==", uid).get();
      await Promise.all(q.docs.map((d) => d.ref.delete()));
    }
    try {
      await admin.storage().bucket().deleteFiles({ prefix: `progress-photos/${uid}/` });
    } catch (e) {
      console.warn("Storage cleanup:", e.message);
    }
    await admin.auth().deleteUser(uid);
    res.status(200).json({ deleted: true });
  })
);
